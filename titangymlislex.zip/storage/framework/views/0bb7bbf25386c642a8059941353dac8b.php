<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\TITANGYMLISLEX\titangym\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>