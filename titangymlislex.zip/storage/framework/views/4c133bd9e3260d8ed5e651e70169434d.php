<?php echo e($slot); ?>

<?php /**PATH C:\TITANGYMLISLEX\titangym\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>