import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentReceiptController::store
 * @see app/Http/Controllers/PaymentReceiptController.php:16
 * @route '/mi-matricula/{enrollment}/comprobante'
 */
export const store = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/mi-matricula/{enrollment}/comprobante',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaymentReceiptController::store
 * @see app/Http/Controllers/PaymentReceiptController.php:16
 * @route '/mi-matricula/{enrollment}/comprobante'
 */
store.url = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { enrollment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { enrollment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    enrollment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        enrollment: typeof args.enrollment === 'object'
                ? args.enrollment.id
                : args.enrollment,
                }

    return store.definition.url
            .replace('{enrollment}', parsedArgs.enrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentReceiptController::store
 * @see app/Http/Controllers/PaymentReceiptController.php:16
 * @route '/mi-matricula/{enrollment}/comprobante'
 */
store.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PaymentReceiptController::store
 * @see app/Http/Controllers/PaymentReceiptController.php:16
 * @route '/mi-matricula/{enrollment}/comprobante'
 */
    const storeForm = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PaymentReceiptController::store
 * @see app/Http/Controllers/PaymentReceiptController.php:16
 * @route '/mi-matricula/{enrollment}/comprobante'
 */
        storeForm.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const PaymentReceiptController = { store }

export default PaymentReceiptController