import SiteController from './SiteController'
import ContactController from './ContactController'
import PlanController from './PlanController'
import EnrollmentController from './EnrollmentController'
import PaymentReceiptController from './PaymentReceiptController'
import DashboardController from './DashboardController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    SiteController: Object.assign(SiteController, SiteController),
ContactController: Object.assign(ContactController, ContactController),
PlanController: Object.assign(PlanController, PlanController),
EnrollmentController: Object.assign(EnrollmentController, EnrollmentController),
PaymentReceiptController: Object.assign(PaymentReceiptController, PaymentReceiptController),
DashboardController: Object.assign(DashboardController, DashboardController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers