import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\EnrollmentController::create
 * @see app/Http/Controllers/EnrollmentController.php:26
 * @route '/matricula/{plan}'
 */
export const create = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/matricula/{plan}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EnrollmentController::create
 * @see app/Http/Controllers/EnrollmentController.php:26
 * @route '/matricula/{plan}'
 */
create.url = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { plan: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.slug
                : args.plan,
                }

    return create.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\EnrollmentController::create
 * @see app/Http/Controllers/EnrollmentController.php:26
 * @route '/matricula/{plan}'
 */
create.get = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EnrollmentController::create
 * @see app/Http/Controllers/EnrollmentController.php:26
 * @route '/matricula/{plan}'
 */
create.head = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EnrollmentController::create
 * @see app/Http/Controllers/EnrollmentController.php:26
 * @route '/matricula/{plan}'
 */
    const createForm = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EnrollmentController::create
 * @see app/Http/Controllers/EnrollmentController.php:26
 * @route '/matricula/{plan}'
 */
        createForm.get = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EnrollmentController::create
 * @see app/Http/Controllers/EnrollmentController.php:26
 * @route '/matricula/{plan}'
 */
        createForm.head = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\EnrollmentController::store
 * @see app/Http/Controllers/EnrollmentController.php:52
 * @route '/matricula/{plan}'
 */
export const store = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/matricula/{plan}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\EnrollmentController::store
 * @see app/Http/Controllers/EnrollmentController.php:52
 * @route '/matricula/{plan}'
 */
store.url = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { plan: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.slug
                : args.plan,
                }

    return store.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\EnrollmentController::store
 * @see app/Http/Controllers/EnrollmentController.php:52
 * @route '/matricula/{plan}'
 */
store.post = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\EnrollmentController::store
 * @see app/Http/Controllers/EnrollmentController.php:52
 * @route '/matricula/{plan}'
 */
    const storeForm = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EnrollmentController::store
 * @see app/Http/Controllers/EnrollmentController.php:52
 * @route '/matricula/{plan}'
 */
        storeForm.post = (args: { plan: string | { slug: string } } | [plan: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\EnrollmentController::show
 * @see app/Http/Controllers/EnrollmentController.php:96
 * @route '/mi-matricula/{enrollment}'
 */
export const show = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/mi-matricula/{enrollment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EnrollmentController::show
 * @see app/Http/Controllers/EnrollmentController.php:96
 * @route '/mi-matricula/{enrollment}'
 */
show.url = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { enrollment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { enrollment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    enrollment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        enrollment: typeof args.enrollment === 'object'
                ? args.enrollment.id
                : args.enrollment,
                }

    return show.definition.url
            .replace('{enrollment}', parsedArgs.enrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\EnrollmentController::show
 * @see app/Http/Controllers/EnrollmentController.php:96
 * @route '/mi-matricula/{enrollment}'
 */
show.get = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EnrollmentController::show
 * @see app/Http/Controllers/EnrollmentController.php:96
 * @route '/mi-matricula/{enrollment}'
 */
show.head = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EnrollmentController::show
 * @see app/Http/Controllers/EnrollmentController.php:96
 * @route '/mi-matricula/{enrollment}'
 */
    const showForm = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EnrollmentController::show
 * @see app/Http/Controllers/EnrollmentController.php:96
 * @route '/mi-matricula/{enrollment}'
 */
        showForm.get = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EnrollmentController::show
 * @see app/Http/Controllers/EnrollmentController.php:96
 * @route '/mi-matricula/{enrollment}'
 */
        showForm.head = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const EnrollmentController = { create, store, show }

export default EnrollmentController