import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/matriculas/nueva',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/matriculas/nueva',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const ManualEnrollmentController = { create, store }

export default ManualEnrollmentController