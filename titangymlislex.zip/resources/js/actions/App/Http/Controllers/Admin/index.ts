import EnrollmentController from './EnrollmentController'
import ManualEnrollmentController from './ManualEnrollmentController'
import EnrollmentReviewController from './EnrollmentReviewController'
import PaymentReceiptController from './PaymentReceiptController'
import ClientController from './ClientController'
import PromotionController from './PromotionController'
const Admin = {
    EnrollmentController: Object.assign(EnrollmentController, EnrollmentController),
ManualEnrollmentController: Object.assign(ManualEnrollmentController, ManualEnrollmentController),
EnrollmentReviewController: Object.assign(EnrollmentReviewController, EnrollmentReviewController),
PaymentReceiptController: Object.assign(PaymentReceiptController, PaymentReceiptController),
ClientController: Object.assign(ClientController, ClientController),
PromotionController: Object.assign(PromotionController, PromotionController),
}

export default Admin