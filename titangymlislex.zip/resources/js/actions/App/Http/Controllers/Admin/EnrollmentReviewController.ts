import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
export const approve = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/matriculas/{enrollment}/aprobar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
approve.url = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { enrollment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { enrollment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    enrollment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        enrollment: typeof args.enrollment === 'object'
                ? args.enrollment.id
                : args.enrollment,
                }

    return approve.definition.url
            .replace('{enrollment}', parsedArgs.enrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
approve.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
    const approveForm = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
        approveForm.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
export const reject = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/matriculas/{enrollment}/rechazar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
reject.url = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { enrollment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { enrollment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    enrollment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        enrollment: typeof args.enrollment === 'object'
                ? args.enrollment.id
                : args.enrollment,
                }

    return reject.definition.url
            .replace('{enrollment}', parsedArgs.enrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
reject.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
    const rejectForm = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
        rejectForm.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const EnrollmentReviewController = { approve, reject }

export default EnrollmentReviewController