import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:16
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:16
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:16
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:16
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:16
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:16
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::home
 * @see app/Http/Controllers/SiteController.php:16
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\SiteController::about
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/nosotros'
 */
export const about = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

about.definition = {
    methods: ["get","head"],
    url: '/nosotros',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::about
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/nosotros'
 */
about.url = (options?: RouteQueryOptions) => {
    return about.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::about
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/nosotros'
 */
about.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::about
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/nosotros'
 */
about.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: about.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::about
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/nosotros'
 */
    const aboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: about.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::about
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/nosotros'
 */
        aboutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: about.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::about
 * @see app/Http/Controllers/SiteController.php:28
 * @route '/nosotros'
 */
        aboutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: about.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    about.form = aboutForm
/**
* @see \App\Http\Controllers\SiteController::services
 * @see app/Http/Controllers/SiteController.php:33
 * @route '/servicios'
 */
export const services = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(options),
    method: 'get',
})

services.definition = {
    methods: ["get","head"],
    url: '/servicios',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::services
 * @see app/Http/Controllers/SiteController.php:33
 * @route '/servicios'
 */
services.url = (options?: RouteQueryOptions) => {
    return services.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::services
 * @see app/Http/Controllers/SiteController.php:33
 * @route '/servicios'
 */
services.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::services
 * @see app/Http/Controllers/SiteController.php:33
 * @route '/servicios'
 */
services.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: services.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::services
 * @see app/Http/Controllers/SiteController.php:33
 * @route '/servicios'
 */
    const servicesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: services.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::services
 * @see app/Http/Controllers/SiteController.php:33
 * @route '/servicios'
 */
        servicesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: services.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::services
 * @see app/Http/Controllers/SiteController.php:33
 * @route '/servicios'
 */
        servicesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: services.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    services.form = servicesForm
/**
* @see \App\Http\Controllers\SiteController::trainers
 * @see app/Http/Controllers/SiteController.php:38
 * @route '/entrenadores'
 */
export const trainers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: trainers.url(options),
    method: 'get',
})

trainers.definition = {
    methods: ["get","head"],
    url: '/entrenadores',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::trainers
 * @see app/Http/Controllers/SiteController.php:38
 * @route '/entrenadores'
 */
trainers.url = (options?: RouteQueryOptions) => {
    return trainers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::trainers
 * @see app/Http/Controllers/SiteController.php:38
 * @route '/entrenadores'
 */
trainers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: trainers.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::trainers
 * @see app/Http/Controllers/SiteController.php:38
 * @route '/entrenadores'
 */
trainers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: trainers.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::trainers
 * @see app/Http/Controllers/SiteController.php:38
 * @route '/entrenadores'
 */
    const trainersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: trainers.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::trainers
 * @see app/Http/Controllers/SiteController.php:38
 * @route '/entrenadores'
 */
        trainersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: trainers.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::trainers
 * @see app/Http/Controllers/SiteController.php:38
 * @route '/entrenadores'
 */
        trainersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: trainers.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    trainers.form = trainersForm
/**
* @see \App\Http\Controllers\SiteController::facilities
 * @see app/Http/Controllers/SiteController.php:43
 * @route '/instalaciones'
 */
export const facilities = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: facilities.url(options),
    method: 'get',
})

facilities.definition = {
    methods: ["get","head"],
    url: '/instalaciones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteController::facilities
 * @see app/Http/Controllers/SiteController.php:43
 * @route '/instalaciones'
 */
facilities.url = (options?: RouteQueryOptions) => {
    return facilities.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteController::facilities
 * @see app/Http/Controllers/SiteController.php:43
 * @route '/instalaciones'
 */
facilities.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: facilities.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteController::facilities
 * @see app/Http/Controllers/SiteController.php:43
 * @route '/instalaciones'
 */
facilities.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: facilities.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteController::facilities
 * @see app/Http/Controllers/SiteController.php:43
 * @route '/instalaciones'
 */
    const facilitiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: facilities.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteController::facilities
 * @see app/Http/Controllers/SiteController.php:43
 * @route '/instalaciones'
 */
        facilitiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: facilities.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteController::facilities
 * @see app/Http/Controllers/SiteController.php:43
 * @route '/instalaciones'
 */
        facilitiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: facilities.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    facilities.form = facilitiesForm
const SiteController = { home, about, services, trainers, facilities }

export default SiteController