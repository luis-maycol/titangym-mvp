import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PromotionController::index
 * @see app/Http/Controllers/Admin/PromotionController.php:19
 * @route '/admin/promociones'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/promociones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PromotionController::index
 * @see app/Http/Controllers/Admin/PromotionController.php:19
 * @route '/admin/promociones'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PromotionController::index
 * @see app/Http/Controllers/Admin/PromotionController.php:19
 * @route '/admin/promociones'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PromotionController::index
 * @see app/Http/Controllers/Admin/PromotionController.php:19
 * @route '/admin/promociones'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PromotionController::index
 * @see app/Http/Controllers/Admin/PromotionController.php:19
 * @route '/admin/promociones'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PromotionController::index
 * @see app/Http/Controllers/Admin/PromotionController.php:19
 * @route '/admin/promociones'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PromotionController::index
 * @see app/Http/Controllers/Admin/PromotionController.php:19
 * @route '/admin/promociones'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\PromotionController::store
 * @see app/Http/Controllers/Admin/PromotionController.php:38
 * @route '/admin/promociones'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/promociones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PromotionController::store
 * @see app/Http/Controllers/Admin/PromotionController.php:38
 * @route '/admin/promociones'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PromotionController::store
 * @see app/Http/Controllers/Admin/PromotionController.php:38
 * @route '/admin/promociones'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PromotionController::store
 * @see app/Http/Controllers/Admin/PromotionController.php:38
 * @route '/admin/promociones'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PromotionController::store
 * @see app/Http/Controllers/Admin/PromotionController.php:38
 * @route '/admin/promociones'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\PromotionController::update
 * @see app/Http/Controllers/Admin/PromotionController.php:59
 * @route '/admin/promociones/{promotion}'
 */
export const update = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/promociones/{promotion}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\PromotionController::update
 * @see app/Http/Controllers/Admin/PromotionController.php:59
 * @route '/admin/promociones/{promotion}'
 */
update.url = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promotion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { promotion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        promotion: typeof args.promotion === 'object'
                ? args.promotion.id
                : args.promotion,
                }

    return update.definition.url
            .replace('{promotion}', parsedArgs.promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PromotionController::update
 * @see app/Http/Controllers/Admin/PromotionController.php:59
 * @route '/admin/promociones/{promotion}'
 */
update.patch = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\PromotionController::update
 * @see app/Http/Controllers/Admin/PromotionController.php:59
 * @route '/admin/promociones/{promotion}'
 */
    const updateForm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PromotionController::update
 * @see app/Http/Controllers/Admin/PromotionController.php:59
 * @route '/admin/promociones/{promotion}'
 */
        updateForm.patch = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\PromotionController::destroy
 * @see app/Http/Controllers/Admin/PromotionController.php:75
 * @route '/admin/promociones/{promotion}'
 */
export const destroy = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/promociones/{promotion}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PromotionController::destroy
 * @see app/Http/Controllers/Admin/PromotionController.php:75
 * @route '/admin/promociones/{promotion}'
 */
destroy.url = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promotion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { promotion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        promotion: typeof args.promotion === 'object'
                ? args.promotion.id
                : args.promotion,
                }

    return destroy.definition.url
            .replace('{promotion}', parsedArgs.promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PromotionController::destroy
 * @see app/Http/Controllers/Admin/PromotionController.php:75
 * @route '/admin/promociones/{promotion}'
 */
destroy.delete = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\PromotionController::destroy
 * @see app/Http/Controllers/Admin/PromotionController.php:75
 * @route '/admin/promociones/{promotion}'
 */
    const destroyForm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PromotionController::destroy
 * @see app/Http/Controllers/Admin/PromotionController.php:75
 * @route '/admin/promociones/{promotion}'
 */
        destroyForm.delete = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const promotions = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default promotions