import enrollments from './enrollments'
import receipts from './receipts'
import clients from './clients'
import promotions from './promotions'
const admin = {
    enrollments: Object.assign(enrollments, enrollments),
receipts: Object.assign(receipts, receipts),
clients: Object.assign(clients, clients),
promotions: Object.assign(promotions, promotions),
}

export default admin