import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PaymentReceiptController::show
 * @see app/Http/Controllers/Admin/PaymentReceiptController.php:15
 * @route '/admin/comprobantes/{receipt}'
 */
export const show = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/comprobantes/{receipt}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PaymentReceiptController::show
 * @see app/Http/Controllers/Admin/PaymentReceiptController.php:15
 * @route '/admin/comprobantes/{receipt}'
 */
show.url = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { receipt: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { receipt: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    receipt: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        receipt: typeof args.receipt === 'object'
                ? args.receipt.id
                : args.receipt,
                }

    return show.definition.url
            .replace('{receipt}', parsedArgs.receipt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PaymentReceiptController::show
 * @see app/Http/Controllers/Admin/PaymentReceiptController.php:15
 * @route '/admin/comprobantes/{receipt}'
 */
show.get = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PaymentReceiptController::show
 * @see app/Http/Controllers/Admin/PaymentReceiptController.php:15
 * @route '/admin/comprobantes/{receipt}'
 */
show.head = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PaymentReceiptController::show
 * @see app/Http/Controllers/Admin/PaymentReceiptController.php:15
 * @route '/admin/comprobantes/{receipt}'
 */
    const showForm = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PaymentReceiptController::show
 * @see app/Http/Controllers/Admin/PaymentReceiptController.php:15
 * @route '/admin/comprobantes/{receipt}'
 */
        showForm.get = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PaymentReceiptController::show
 * @see app/Http/Controllers/Admin/PaymentReceiptController.php:15
 * @route '/admin/comprobantes/{receipt}'
 */
        showForm.head = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const receipts = {
    show: Object.assign(show, show),
}

export default receipts