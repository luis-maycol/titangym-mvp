import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\EnrollmentController::index
 * @see app/Http/Controllers/Admin/EnrollmentController.php:20
 * @route '/admin/matriculas'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/matriculas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\EnrollmentController::index
 * @see app/Http/Controllers/Admin/EnrollmentController.php:20
 * @route '/admin/matriculas'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EnrollmentController::index
 * @see app/Http/Controllers/Admin/EnrollmentController.php:20
 * @route '/admin/matriculas'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\EnrollmentController::index
 * @see app/Http/Controllers/Admin/EnrollmentController.php:20
 * @route '/admin/matriculas'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\EnrollmentController::index
 * @see app/Http/Controllers/Admin/EnrollmentController.php:20
 * @route '/admin/matriculas'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\EnrollmentController::index
 * @see app/Http/Controllers/Admin/EnrollmentController.php:20
 * @route '/admin/matriculas'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\EnrollmentController::index
 * @see app/Http/Controllers/Admin/EnrollmentController.php:20
 * @route '/admin/matriculas'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/matriculas/nueva',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::create
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:27
 * @route '/admin/matriculas/nueva'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/matriculas/nueva',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ManualEnrollmentController::store
 * @see app/Http/Controllers/Admin/ManualEnrollmentController.php:41
 * @route '/admin/matriculas/nueva'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\EnrollmentController::show
 * @see app/Http/Controllers/Admin/EnrollmentController.php:60
 * @route '/admin/matriculas/{enrollment}'
 */
export const show = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/matriculas/{enrollment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\EnrollmentController::show
 * @see app/Http/Controllers/Admin/EnrollmentController.php:60
 * @route '/admin/matriculas/{enrollment}'
 */
show.url = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { enrollment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { enrollment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    enrollment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        enrollment: typeof args.enrollment === 'object'
                ? args.enrollment.id
                : args.enrollment,
                }

    return show.definition.url
            .replace('{enrollment}', parsedArgs.enrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EnrollmentController::show
 * @see app/Http/Controllers/Admin/EnrollmentController.php:60
 * @route '/admin/matriculas/{enrollment}'
 */
show.get = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\EnrollmentController::show
 * @see app/Http/Controllers/Admin/EnrollmentController.php:60
 * @route '/admin/matriculas/{enrollment}'
 */
show.head = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\EnrollmentController::show
 * @see app/Http/Controllers/Admin/EnrollmentController.php:60
 * @route '/admin/matriculas/{enrollment}'
 */
    const showForm = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\EnrollmentController::show
 * @see app/Http/Controllers/Admin/EnrollmentController.php:60
 * @route '/admin/matriculas/{enrollment}'
 */
        showForm.get = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\EnrollmentController::show
 * @see app/Http/Controllers/Admin/EnrollmentController.php:60
 * @route '/admin/matriculas/{enrollment}'
 */
        showForm.head = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
export const approve = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/matriculas/{enrollment}/aprobar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
approve.url = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { enrollment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { enrollment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    enrollment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        enrollment: typeof args.enrollment === 'object'
                ? args.enrollment.id
                : args.enrollment,
                }

    return approve.definition.url
            .replace('{enrollment}', parsedArgs.enrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
approve.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
    const approveForm = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::approve
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:19
 * @route '/admin/matriculas/{enrollment}/aprobar'
 */
        approveForm.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
export const reject = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/matriculas/{enrollment}/rechazar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
reject.url = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { enrollment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { enrollment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    enrollment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        enrollment: typeof args.enrollment === 'object'
                ? args.enrollment.id
                : args.enrollment,
                }

    return reject.definition.url
            .replace('{enrollment}', parsedArgs.enrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
reject.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
    const rejectForm = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EnrollmentReviewController::reject
 * @see app/Http/Controllers/Admin/EnrollmentReviewController.php:35
 * @route '/admin/matriculas/{enrollment}/rechazar'
 */
        rejectForm.post = (args: { enrollment: number | { id: number } } | [enrollment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const enrollments = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
approve: Object.assign(approve, approve),
reject: Object.assign(reject, reject),
}

export default enrollments